package com.example.e_doclocker;
public class SMSManager{

}